from gui import MainWindow


mw = MainWindow()